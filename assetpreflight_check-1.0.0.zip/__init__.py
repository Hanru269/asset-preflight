"""Asset Preflight: check meshes and UVs the way a game engine sees them, fix what is safe, and prove the fix."""
import json

import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import core

LITE = True          # the free check-only build (build_lite.py) sets this to True and renames the identifiers


class PreflightCheckSettings(bpy.types.PropertyGroup):
    tri_budget: IntProperty(name="Triangle budget", default=0, min=0, description="Warn when an object has more triangles than this. 0 turns the check off")
    tex_px: EnumProperty(name="Texture size", default="1024", items=[(str(n), f"{n} px", "") for n in (256, 512, 1024, 2048, 4096, 8192)],
                         description="Used to report texel density (pixels per metre). Only the relative spread affects the verdict")
    texel_tol: FloatProperty(name="Texel tolerance (%)", default=15.0, min=1.0, max=100.0, description="A face is 'off' when its texel density differs from the median by more than this")
    allow_udim: BoolProperty(name="Allow UDIM / tiled UVs", default=False, description="Do not warn about UVs outside the 0-1 tile")
    triangulate: BoolProperty(name="Triangulate n-gons when fixing", default=False, description="Also triangulate n-gons in Fix Geometry")
    report: StringProperty(default="")


def _settings(context):
    p = context.scene.preflightcheck
    return p, core.Settings(tri_budget=p.tri_budget, tex_px=int(p.tex_px), texel_tol=p.texel_tol / 100.0, allow_udim=p.allow_udim)


def _targets(context):
    objs = [o for o in context.selected_objects if o.type == "MESH"]
    if not objs and context.active_object is not None and context.active_object.type == "MESH":
        objs = [context.active_object]
    if not objs:
        raise ValueError("Select one or more mesh objects first.")
    return objs


def _store(context, results):
    context.scene.preflightcheck.report = json.dumps(results)


def _run_checks(context, objs, s):
    scale_m = context.scene.unit_settings.scale_length or 1.0
    out = []
    for o in objs:
        r, facts = core.analyze(o, s)
        state, found = core.verdict(r)
        if "texel_median_px_per_unit" in facts:
            for k in ("texel_median_px_per_unit", "texel_min", "texel_max"):
                facts[k.replace("_px_per_unit", "") + "_px_per_m"] = round(facts.pop(k) / scale_m, 1)
        out.append({"name": o.name, "state": state, "found": [[core.LABEL[k], sv, n] for k, sv, n in found], "facts": facts})
    return out


class PREFLIGHTCHECK_OT_run(bpy.types.Operator):
    bl_idname = "preflightcheck.run"
    bl_label = "Run Preflight"
    bl_description = "Check the selected meshes and list every problem with its count"

    def execute(self, context):
        try:
            objs = _targets(context)
            _p, s = _settings(context)
            res = _run_checks(context, objs, s)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        _store(context, res)
        bad = [r["name"] for r in res if r["state"] != "READY"]
        self.report({"INFO" if not bad else "WARNING"}, f"{len(res)} object(s) checked: " + ("all READY." if not bad else f"{len(bad)} need attention ({', '.join(bad[:4])}{'...' if len(bad) > 4 else ''})."))
        return {"FINISHED"}


def _guarded(operator, context, name, work, verify_shape=True):
    """Run `work(obj)` on every target; if a fix ever changes the shape, roll that object back and say so."""
    objs = _targets(context)
    p, s = _settings(context)
    log, done = [], 0
    for o in objs:
        snap_mesh, snap_scale = o.data.copy(), tuple(o.scale)
        before = core.measure(o)
        try:
            steps = work(o, s, p)
            if verify_shape and not core.same_shape(before, core.measure(o)):
                raise RuntimeError("the shape changed, which a fix must never do")
        except (ValueError, RuntimeError) as e:
            old = o.data
            o.data, o.scale = snap_mesh, snap_scale
            if old is not snap_mesh and old.users == 0:
                bpy.data.meshes.remove(old)
            operator.report({"ERROR"}, f"{o.name}: {e}. The object was left as it was.")
            continue
        bpy.data.meshes.remove(snap_mesh)
        done += 1
        log += [f"{o.name}: {t}" for t in steps]
    res = _run_checks(context, objs, s)
    _store(context, res)
    for line in log[:12]:
        operator.report({"INFO"}, line)
    ready = sum(1 for r in res if r["state"] == "READY")
    operator.report({"INFO"}, f"{name}: {done}/{len(objs)} object(s) fixed; re-checked: {ready}/{len(res)} READY.")
    return {"FINISHED"}


class PREFLIGHTCHECK_OT_fix_safe(bpy.types.Operator):
    bl_idname = "preflightcheck.fix_safe"
    bl_label = "Fix Transforms + Geometry"
    bl_description = "Apply scale, remove loose geometry, weld duplicates, fix flipped normals, drop empty material slots. Shape is verified unchanged"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        def work(o, s, p):
            return core.fix_transforms(o) + core.fix_geometry(o, s, triangulate=p.triangulate)
        try:
            return _guarded(self, context, "Fix", work)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class PREFLIGHTCHECK_OT_fix_uv(bpy.types.Operator):
    bl_idname = "preflightcheck.fix_uv"
    bl_label = "Fix UVs (repack)"
    bl_description = "Create UVs if missing, equalise texel density between islands, repack into the 0-1 tile. Overlapping UVs that were intentional (mirrored halves) will be separated"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        def work(o, s, p):
            return core.fix_uv(o, s)
        try:
            return _guarded(self, context, "UV fix", work)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class PREFLIGHTCHECK_OT_select(bpy.types.Operator):
    bl_idname = "preflightcheck.select"
    bl_label = "Select Problem Geometry"
    bl_description = "In Edit Mode, select the geometry that a check flagged"
    which: EnumProperty(name="Problem", items=[("NGONS", "N-gons", ""), ("ZERO", "Zero-area faces", ""), ("LOOSE", "Loose vertices/edges", ""), ("UVOUT", "Faces with UVs outside 0-1", "")])

    @classmethod
    def poll(cls, context):
        return context.mode == "EDIT_MESH"

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        for f in bm.faces:
            f.select_set(False)
        n = 0
        uv = bm.loops.layers.uv.active
        for f in bm.faces:
            hit = (self.which == "NGONS" and len(f.verts) > 4) or (self.which == "ZERO" and f.calc_area() < 1e-12)
            if self.which == "UVOUT" and uv is not None:
                hit = any(l[uv].uv.x < -1e-4 or l[uv].uv.y < -1e-4 or l[uv].uv.x > 1.0001 or l[uv].uv.y > 1.0001 for l in f.loops)
            if hit:
                f.select_set(True)
                n += 1
        if self.which == "LOOSE":
            for v in bm.verts:
                if not v.link_edges:
                    v.select_set(True)
                    n += 1
            for e in bm.edges:
                if not e.link_faces:
                    e.select_set(True)
                    n += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({"INFO"}, f"Selected {n} item(s).")
        return {"FINISHED"}


class PREFLIGHTCHECK_OT_report(bpy.types.Operator):
    bl_idname = "preflightcheck.report"
    bl_label = "Write Report"
    bl_description = "Write the last results into a text block named 'Asset Preflight report'"

    def execute(self, context):
        try:
            res = json.loads(context.scene.preflightcheck.report)
        except ValueError:
            self.report({"ERROR"}, "Run Preflight first.")
            return {"CANCELLED"}
        lines = ["ASSET PREFLIGHT REPORT", ""]
        for r in res:
            lines.append(f"{r['name']}: {r['state']}")
            for label, sv, n in r["found"]:
                lines.append(f"   [{sv}] {label}: {n}")
            for k, v in r["facts"].items():
                lines.append(f"   {k}: {v}")
            lines.append("")
        t = bpy.data.texts.get("Asset Preflight report") or bpy.data.texts.new("Asset Preflight report")
        t.clear()
        t.write("\n".join(lines))
        self.report({"INFO"}, "Report written to the text block 'Asset Preflight report'.")
        return {"FINISHED"}


class PREFLIGHTCHECK_PT_panel(bpy.types.Panel):
    bl_label = "Asset Preflight Check"
    bl_idname = "PREFLIGHTCHECK_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Preflight Check"

    def draw(self, context):
        lay = self.layout
        p = context.scene.preflightcheck
        box = lay.box()
        col = box.column(align=True)
        col.prop(p, "tex_px")
        col.prop(p, "texel_tol")
        col.prop(p, "tri_budget")
        box.prop(p, "allow_udim")
        if not LITE:
            box.prop(p, "triangulate")
        col = lay.column(align=True)
        col.operator("preflightcheck.run", icon="VIEWZOOM")
        if not LITE:
            col.operator("preflightcheck.fix_safe", icon="MODIFIER")
            col.operator("preflightcheck.fix_uv", icon="UV")
        col.operator("preflightcheck.report", icon="TEXT")
        if context.mode == "EDIT_MESH":
            sel = lay.box()
            sel.label(text="Select problem geometry")
            for w, label in (("NGONS", "N-gons"), ("ZERO", "Zero-area faces"), ("LOOSE", "Loose geometry"), ("UVOUT", "UVs outside 0-1")):
                sel.operator("preflightcheck.select", text=label).which = w
        if p.report:
            try:
                res = json.loads(p.report)
            except ValueError:
                return
            for r in res[:8]:
                b = lay.box()
                b.label(text=f"{r['name']}: {r['state']}", icon={"READY": "CHECKMARK", "WARNINGS": "ERROR", "ERRORS": "CANCEL"}[r["state"]])
                for label, sv, n in r["found"][:10]:
                    b.label(text=f"{label}: {n}", icon={"error": "CANCEL", "warn": "ERROR", "info": "INFO"}[sv])
            if len(res) > 8:
                lay.label(text=f"...and {len(res) - 8} more (use Write Report)")


_CLASSES = ((PreflightCheckSettings, PREFLIGHTCHECK_OT_run, PREFLIGHTCHECK_OT_select, PREFLIGHTCHECK_OT_report, PREFLIGHTCHECK_PT_panel) if LITE else
            (PreflightCheckSettings, PREFLIGHTCHECK_OT_run, PREFLIGHTCHECK_OT_fix_safe, PREFLIGHTCHECK_OT_fix_uv, PREFLIGHTCHECK_OT_select, PREFLIGHTCHECK_OT_report, PREFLIGHTCHECK_PT_panel))


def register():
    for c in _CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.preflightcheck = PointerProperty(type=PreflightCheckSettings)


def unregister():
    del bpy.types.Scene.preflightcheck
    for c in reversed(_CLASSES):
        bpy.utils.unregister_class(c)
