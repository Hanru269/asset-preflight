"""Asset Preflight engine: measure a mesh the way a game engine will see it, fix what is safe to fix, and re-measure.

Lengths are in Blender units unless a name says otherwise. Every check returns numbers, never opinions; severity is
assigned in one place (SEVERITY) so the report, the panel and the tests agree.
"""
import math

import bmesh
import bpy
import numpy as np
from mathutils import Vector

SEVERITY = {                     # what the panel shows; "error" blocks the READY verdict, "warn" too, "info" never does
    "scale_unapplied": "error", "scale_negative": "error", "no_uv": "error", "uv_out_of_bounds": "warn", "uv_overlap": "warn",
    "texel_spread": "warn", "uv_stretch": "info", "uv_degenerate": "warn", "ngons": "warn", "loose": "warn", "doubles": "warn", "zero_area": "warn",
    "inconsistent_normals": "error", "over_budget": "warn", "empty_slots": "warn", "unused_slots": "info", "modifiers": "info",
    "open_edges": "info", "multi_uv": "info", "no_material": "info",
}
LABEL = {
    "scale_unapplied": "Object scale is not 1 (apply it)", "scale_negative": "Negative scale (mirrored object)", "no_uv": "No UV map",
    "uv_out_of_bounds": "UVs outside the 0-1 tile", "uv_overlap": "Overlapping UV islands", "texel_spread": "Islands with uneven texel density", "uv_stretch": "Stretched UV faces (far from their island's density)",
    "uv_degenerate": "Zero-area UV faces", "ngons": "N-gons (more than 4 sides)", "loose": "Loose vertices/edges", "doubles": "Duplicate vertices",
    "zero_area": "Zero-area faces", "inconsistent_normals": "Flipped/inconsistent face normals", "over_budget": "Triangle count over budget",
    "empty_slots": "Empty material slots", "unused_slots": "Unused material slots", "modifiers": "Unapplied modifiers (evaluated mesh is checked)",
    "open_edges": "Open or non-manifold edges (matters for printing)", "multi_uv": "More than one UV map", "no_material": "No material",
}


class Settings:
    def __init__(self, tri_budget=0, tex_px=1024, texel_tol=0.15, overlap_tol=0.005, allow_udim=False, merge_dist=1e-4, raster=512):
        self.tri_budget, self.tex_px, self.texel_tol, self.overlap_tol = tri_budget, tex_px, texel_tol, overlap_tol
        self.allow_udim, self.merge_dist, self.raster = allow_udim, merge_dist, raster


def eval_bmesh(obj, world=True):
    """The mesh as it will be exported (modifiers applied), as a bmesh the caller frees. `world` bakes the object matrix in."""
    ev = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    me = ev.to_mesh()
    try:
        bm = bmesh.new()
        bm.from_mesh(me)
    finally:
        ev.to_mesh_clear()
    if world:
        bm.transform(obj.matrix_world)
    return bm


# ------------------------------------------------------------------ UV maths
def _poly_area2(pts):
    return 0.5 * abs(sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts))))


def uv_islands(bm, uv):
    """Face index -> island id. Two faces are one island when they share an edge AND agree on both UV positions along it."""
    parent = list(range(len(bm.faces)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        f1, f2 = e.link_faces
        ok = True
        for v in e.verts:
            u1 = next(l[uv].uv for l in f1.loops if l.vert == v)
            u2 = next(l[uv].uv for l in f2.loops if l.vert == v)
            if (u1 - u2).length > 1e-5:
                ok = False
                break
        if ok:
            parent[find(f1.index)] = find(f2.index)
    roots = {}
    return [roots.setdefault(find(f.index), len(roots)) for f in bm.faces]


def uv_stats(bm, uv, s):
    """UV bounds, degenerate faces, per-face texel density (px per unit of length in `bm`), islands and overlap %."""
    n = len(bm.faces)
    dens = np.zeros(n)
    degenerate = 0
    outside = 0
    tris, owner_of_tri = [], []
    isl = uv_islands(bm, uv)
    for f in bm.faces:
        pts = [tuple(l[uv].uv) for l in f.loops]
        ua = _poly_area2(pts)
        a3 = f.calc_area()
        if ua < 1e-12 or a3 < 1e-12:
            degenerate += 1 if ua < 1e-12 and a3 >= 1e-12 else 0
            dens[f.index] = np.nan
        else:
            dens[f.index] = math.sqrt(ua / a3) * s.tex_px
        if any(p[0] < -1e-4 or p[1] < -1e-4 or p[0] > 1 + 1e-4 or p[1] > 1 + 1e-4 for p in pts):
            outside += 1
        for i in range(1, len(pts) - 1):
            tris.append((pts[0], pts[i], pts[i + 1]))
            owner_of_tri.append(isl[f.index])
    return {"dens": dens, "degenerate": degenerate, "outside_faces": outside, "islands": isl, "tris": tris, "tri_owner": owner_of_tri}


def overlap_fraction(tris, owner, res):
    """Share of covered UV pixels that more than one island covers (raster estimate at res x res)."""
    if not tris:
        return 0.0
    grid = np.full((res, res), -1, dtype=np.int32)
    over = np.zeros((res, res), dtype=bool)
    for (a, b, c), o in zip(tris, owner):
        xs = [a[0], b[0], c[0]]
        ys = [a[1], b[1], c[1]]
        x0, x1 = max(0, int(min(xs) * res)), min(res - 1, int(max(xs) * res))
        y0, y1 = max(0, int(min(ys) * res)), min(res - 1, int(max(ys) * res))
        if x1 < x0 or y1 < y0:
            continue
        px, py = np.meshgrid((np.arange(x0, x1 + 1) + 0.5) / res, (np.arange(y0, y1 + 1) + 0.5) / res)
        d = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(d) < 1e-14:
            continue
        w1 = ((b[1] - c[1]) * (px - c[0]) + (c[0] - b[0]) * (py - c[1])) / d
        w2 = ((c[1] - a[1]) * (px - c[0]) + (a[0] - c[0]) * (py - c[1])) / d
        m = (w1 > 1e-9) & (w2 > 1e-9) & (1 - w1 - w2 > 1e-9)          # strict: shared edges are not overlap
        sub = grid[y0:y1 + 1, x0:x1 + 1]
        other = m & (sub != -1) & (sub != o)
        over[y0:y1 + 1, x0:x1 + 1] |= other
        sub[m & (sub == -1)] = o
    covered = int((grid != -1).sum())
    return float(over.sum()) / covered if covered else 0.0


# ------------------------------------------------------------------ analysis
def analyze(obj, s=None):
    """Numbers for one mesh object: {check_key: value}, plus 'facts'. Nonzero value = the check found something."""
    s = s or Settings()
    r = {k: 0 for k in SEVERITY}
    facts = {}
    sc = obj.scale
    r["scale_unapplied"] = int(any(abs(x - 1.0) > 1e-4 for x in sc))
    r["scale_negative"] = int(any(x < 0 for x in sc))
    r["modifiers"] = len([m for m in obj.modifiers if m.show_viewport])
    bm = eval_bmesh(obj)
    try:
        facts["verts"], facts["faces"] = len(bm.verts), len(bm.faces)
        facts["tris"] = sum(len(f.verts) - 2 for f in bm.faces)
        r["over_budget"] = facts["tris"] if s.tri_budget and facts["tris"] > s.tri_budget else 0
        r["ngons"] = sum(1 for f in bm.faces if len(f.verts) > 4)
        r["loose"] = sum(1 for v in bm.verts if not v.link_edges) + sum(1 for e in bm.edges if not e.link_faces)
        r["doubles"] = len(bmesh.ops.find_doubles(bm, verts=bm.verts, dist=s.merge_dist)["targetmap"])
        diag = max((Vector(obj.dimensions)).length, 1e-9)
        r["zero_area"] = sum(1 for f in bm.faces if f.calc_area() < 1e-12 * diag * diag)
        r["inconsistent_normals"] = sum(1 for e in bm.edges if len(e.link_faces) == 2 and e.link_loops[0].vert == e.link_loops[1].vert)
        r["open_edges"] = sum(1 for e in bm.edges if len(e.link_faces) != 2 and e.link_faces)
        slots = obj.material_slots
        r["empty_slots"] = sum(1 for m in slots if m.material is None)
        used = {p.material_index for p in obj.data.polygons}
        r["unused_slots"] = sum(1 for i in range(len(slots)) if i not in used)
        r["no_material"] = int(len(slots) == 0)
        uvl = bm.loops.layers.uv
        r["multi_uv"] = int(len(uvl) > 1)
        if not uvl:
            r["no_uv"] = 1
        else:
            st = uv_stats(bm, uvl.active or uvl[0], s)
            good = st["dens"][~np.isnan(st["dens"])]
            facts["islands"] = len(set(st["islands"]))
            if not s.allow_udim:
                r["uv_out_of_bounds"] = st["outside_faces"]
            r["uv_degenerate"] = st["degenerate"]
            ov = overlap_fraction(st["tris"], st["tri_owner"], s.raster)
            facts["uv_overlap_pct"] = round(100 * ov, 2)
            r["uv_overlap"] = int(ov > s.overlap_tol)
            if len(good):
                med = float(np.median(good))
                facts["texel_median_px_per_unit"] = round(med, 2)
                facts["texel_min"], facts["texel_max"] = round(float(good.min()), 2), round(float(good.max()), 2)
                per = {}
                for i, d in enumerate(st["dens"]):
                    if not np.isnan(d):
                        per.setdefault(st["islands"][i], []).append(d)
                imed = {k: float(np.median(v)) for k, v in per.items()}
                # an island is "off" when its own median density is more than tol away from the overall median
                r["texel_spread"] = sum(1 for m in imed.values() if abs(m - med) > s.texel_tol * med)
                facts["islands_off_pct"] = round(100.0 * r["texel_spread"] / len(imed), 1)
                # stretch: faces far from THEIR island's density (projection distortion), informational
                r["uv_stretch"] = sum(1 for i, d in enumerate(st["dens"]) if not np.isnan(d) and abs(d - imed[st["islands"][i]]) > 2 * s.texel_tol * imed[st["islands"][i]])
    finally:
        bm.free()
    return r, facts


def verdict(r):
    """('READY'|'WARNINGS'|'ERRORS', [(key, severity, count)...]) sorted worst first."""
    found = [(k, SEVERITY[k], v) for k, v in r.items() if v]
    order = {"error": 0, "warn": 1, "info": 2}
    found.sort(key=lambda x: (order[x[1]], x[0]))
    if any(sv == "error" for _k, sv, _v in found):
        return "ERRORS", found
    if any(sv == "warn" for _k, sv, _v in found):
        return "WARNINGS", found
    return "READY", found


# ------------------------------------------------------------------ fixes (each returns a list of human-readable steps)
def measure(obj):
    """Geometry fingerprint used to prove a fix did not change the shape: world bounding box and surface area."""
    bm = eval_bmesh(obj)
    try:
        pts = [v.co for v in bm.verts if v.link_faces]           # loose vertices are not part of the shape
        lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts))) if pts else Vector()
        hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts))) if pts else Vector()
        return {"lo": lo, "hi": hi, "area": sum(f.calc_area() for f in bm.faces)}
    finally:
        bm.free()


def same_shape(a, b, tol=1e-3):
    d = max((a["hi"] - a["lo"]).length, 1e-9)
    return (a["lo"] - b["lo"]).length <= tol * d and (a["hi"] - b["hi"]).length <= tol * d and abs(a["area"] - b["area"]) <= tol * max(a["area"], 1e-9) * 10


def fix_transforms(obj):
    """Bake scale into the mesh (rotation and location stay). A negative scale also flips the faces so normals stay outward."""
    steps = []
    sc = Vector(obj.scale)
    if all(abs(x - 1.0) <= 1e-4 for x in sc):
        return steps
    if obj.children:
        raise ValueError(f"{obj.name} has child objects: applying its scale would move them. Unparent or apply manually.")
    if obj.data.users > 1:
        obj.data = obj.data.copy()
        steps.append("Made the mesh single-user so the shared copies are untouched.")
    from mathutils import Matrix
    obj.data.transform(Matrix.Diagonal((*sc, 1.0)))
    neg = sc.x * sc.y * sc.z < 0
    obj.scale = (1.0, 1.0, 1.0)
    if neg:
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bmesh.ops.reverse_faces(bm, faces=bm.faces)
        bm.to_mesh(obj.data)
        bm.free()
    obj.data.update()
    steps.append("Applied scale " + ", ".join(f"{x:.4g}" for x in sc) + (" (negative scale: faces flipped to keep normals outward)." if neg else "."))
    return steps


def fix_geometry(obj, s=None, triangulate=False):
    """Remove loose geometry, weld duplicates, drop degenerate faces, make normals consistent, remove empty material slots."""
    s = s or Settings()
    steps = []
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    loose_e = [e for e in bm.edges if not e.link_faces]
    if loose_e:
        bmesh.ops.delete(bm, geom=loose_e, context="EDGES")
    loose_v = [v for v in bm.verts if not v.link_edges]
    if loose_v:
        bmesh.ops.delete(bm, geom=loose_v, context="VERTS")
    if loose_e or loose_v:
        steps.append(f"Removed {len(loose_e) + len(loose_v)} loose vertices/edges.")
    before = len(bm.verts)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=s.merge_dist)
    bmesh.ops.dissolve_degenerate(bm, dist=s.merge_dist, edges=bm.edges)
    if len(bm.verts) != before:
        steps.append(f"Welded {before - len(bm.verts)} duplicate vertices.")
    inc = sum(1 for e in bm.edges if len(e.link_faces) == 2 and e.link_loops[0].vert == e.link_loops[1].vert)
    if inc:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        steps.append(f"Made {inc} inconsistent face-normal edges consistent (normals recalculated outward).")
    if triangulate:
        ng = [f for f in bm.faces if len(f.verts) > 4]
        if ng:
            bmesh.ops.triangulate(bm, faces=ng)
            steps.append(f"Triangulated {len(ng)} n-gons.")
    bm.to_mesh(me)
    bm.free()
    slots = list(obj.material_slots)
    empty = [i for i, sl in enumerate(slots) if sl.material is None]
    if empty:
        # clear() keeps the object's slot list in sync (pop() leaves it stale), so rebuild the list and remap each face's index
        remap, keep = {}, []
        for i, sl in enumerate(slots):
            if sl.material is not None:
                remap[i] = len(keep)
                keep.append(sl.material)
        old_idx = [p.material_index for p in me.polygons]
        me.materials.clear()
        for m in keep:
            me.materials.append(m)
        for p, oi in zip(me.polygons, old_idx):
            p.material_index = remap.get(oi, 0)               # faces that used an empty slot fall back to the first material
        steps.append(f"Removed {len(empty)} empty material slot(s).")
    me.update()
    return steps


class _EditMode:
    """Make `obj` the active, selected object and enter Edit Mode; restores the previous active object on exit."""
    def __init__(self, obj):
        self.obj = obj

    def __enter__(self):
        vl = bpy.context.view_layer
        self.prev, self.was_selected = vl.objects.active, self.obj.select_get()
        for o in vl.objects:
            o.select_set(False)
        self.obj.select_set(True)
        vl.objects.active = self.obj
        self.ctx = bpy.context.temp_override(object=self.obj, active_object=self.obj, selected_objects=[self.obj], selected_editable_objects=[self.obj])
        self.ctx.__enter__()
        bpy.ops.object.mode_set(mode="EDIT")
        return self

    def __exit__(self, *exc):
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        finally:
            self.ctx.__exit__(*exc)
            vl = bpy.context.view_layer
            self.obj.select_set(self.was_selected)
            vl.objects.active = self.prev
        return False


def fix_uv(obj, s=None):
    """Create UVs if missing, equalise texel density between islands, then repack into the 0-1 tile."""
    s = s or Settings()
    steps = []
    me = obj.data
    if not me.uv_layers:
        me.uv_layers.new(name="UVMap")
        with _EditMode(obj):
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.003)
        steps.append("Created a UV map with Smart UV Project.")
    bm = eval_bmesh(obj)          # world scale baked, so density means px per real unit
    bm.faces.ensure_lookup_table()
    uv = bm.loops.layers.uv.active
    st = uv_stats(bm, uv, s)
    isl = st["islands"]
    dens = st["dens"]
    per = {}
    for f in bm.faces:
        if not np.isnan(dens[f.index]):
            per.setdefault(isl[f.index], []).append(dens[f.index])
    good = dens[~np.isnan(dens)]
    bm.free()
    if len(good):
        target = float(np.median(good))
        me_bm = bmesh.new()
        me_bm.from_mesh(me)
        me_bm.faces.ensure_lookup_table()
        uvl = me_bm.loops.layers.uv.active
        # island ids are identical for the object's own mesh when there are no evaluated modifiers; guard anyway
        if len(me_bm.faces) == len(isl):
            factor = {i: target / float(np.median(v)) for i, v in per.items() if np.median(v) > 0}
            cen = {}
            for f in me_bm.faces:
                for l in f.loops:
                    c = cen.setdefault(isl[f.index], [0.0, 0.0, 0])
                    c[0] += l[uvl].uv.x
                    c[1] += l[uvl].uv.y
                    c[2] += 1
            for f in me_bm.faces:
                k = factor.get(isl[f.index], 1.0)
                cx, cy = cen[isl[f.index]][0] / cen[isl[f.index]][2], cen[isl[f.index]][1] / cen[isl[f.index]][2]
                for l in f.loops:
                    l[uvl].uv = (cx + (l[uvl].uv.x - cx) * k, cy + (l[uvl].uv.y - cy) * k)
            me_bm.to_mesh(me)
            steps.append(f"Equalised texel density across {len(per)} islands to the median ({target:.0f} px per unit at {s.tex_px} px).")
        me_bm.free()
    with _EditMode(obj):
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.select_all(action="SELECT")
        bpy.ops.uv.pack_islands(rotate=False, margin=max(0.002, 2.0 / s.tex_px))
    steps.append("Packed the islands into the 0-1 tile (no rotation, no overlap).")
    me.update()
    return steps
